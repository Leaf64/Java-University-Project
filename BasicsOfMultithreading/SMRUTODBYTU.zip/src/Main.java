import GUI.MyForm;

public class Main {


    public static void main(String[] args) {

        MyForm gui = new MyForm();
        gui.startGui();
    }
}
